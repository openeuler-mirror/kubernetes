# Kubernetes Dashboard

Kubernetes Dashboard is a general purpose, web-based UI for Kubernetes clusters.
It allows users to manage applications running in the cluster, troubleshoot them,
as well as manage the cluster itself.

Learn more at: https://github.com/kubernetes/dashboard
