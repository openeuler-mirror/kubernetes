# Collecting Docker Log Files with Fluentd and sending to GCP.

The image was moved to the
[new location](https://github.com/kubernetes/contrib/tree/master/fluentd/fluentd-gcp-image).
